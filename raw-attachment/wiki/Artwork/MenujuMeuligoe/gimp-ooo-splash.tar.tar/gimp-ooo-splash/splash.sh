sudo cp gimp-splash.png /usr/share/gimp/2.0/images/gimp-splash.png
sudo cp openintro_ubuntu_sun.bmp /usr/lib/openoffice/program/openintro_ubuntu_sun.bmp
sudo cp openabout_ubuntu_sun.bmp /usr/lib/openoffice/program/openabout_ubuntu_sun.bmp

